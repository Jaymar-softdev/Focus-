# Pixel Tasker — Setup & Packaging Guide

Pixel Tasker is a single-page app (`index.html` + `manifest.json` + `sw.js`). Everything —
your tasks, folders, and calendar entries — is saved in the browser's local storage on
your device, so nothing needs a server or internet connection once it's loaded.

## 1. Try it right now

Just open `index.html` in a browser (double-click it, or drag it into a browser window).
Everything works offline immediately.

## 2. Easiest path: install it as an app (PWA) — no build tools needed

This is the fastest way to get something that looks and feels like a real installed app
on desktop **and** mobile, with its own icon and window.

1. Put the whole `pixel-tasker` folder on a webserver. The simplest way, from inside the
   folder, run:
   ```
   python3 -m http.server 8080
   ```
   (or use any static host — GitHub Pages, Netlify, Vercel, etc. all work great for this
   and are free.)
2. Visit `http://localhost:8080` (or your hosted URL) in Chrome/Edge (desktop or Android)
   or Safari (iOS).
3. **Desktop Chrome/Edge:** click the install icon in the address bar (⊕ or a small
   monitor icon) → "Install Pixel Tasker."
4. **Android Chrome:** menu (⋮) → "Add to Home screen" / "Install app."
5. **iOS Safari:** Share button → "Add to Home Screen."

It now opens in its own window/icon, works offline (thanks to `sw.js`), and updates
automatically whenever you redeploy the files. No app store, no code signing.

## 3. Desktop executable (Windows / macOS / Linux) with Electron

This wraps the app in a real `.exe` / `.dmg` / `.AppImage` you can double-click, no
browser required. The `electron/main.js` and `package.json` files are already set up for
this — you just need Node.js installed (get it from nodejs.org).

From inside the `pixel-tasker` folder:

```bash
npm install
npm start          # launches the app in a desktop window to test it
npm run dist        # builds the installer/executable for your current OS
```

The finished file appears in a new `dist/` folder:
- Windows → an `.exe` installer
- macOS → a `.dmg`
- Linux → an `.AppImage`

Notes:
- Building a Windows `.exe` from macOS/Linux (or vice versa) usually needs extra setup
  (Wine, or a CI runner on the target OS). Building on the OS you're targeting is
  simplest.
- To change the app name or icon, edit the `build` section of `package.json`.

## 4. Mobile app (Android / iOS) with Capacitor

This turns the same web app into a real Android/iOS project you can build in Android
Studio or Xcode, run on a phone or emulator, and eventually submit to the Play Store /
App Store. A `capacitor.config.json` is already included in this folder, pre-filled with
this app's name and ID, so you can skip the interactive prompts from `cap init`.

### Prerequisites

| For | Install |
|---|---|
| Both platforms | [Node.js](https://nodejs.org) 18+ and npm |
| Android | [Android Studio](https://developer.android.com/studio) (installs the Android SDK too) |
| iOS | Xcode (Mac App Store) — **macOS only**, iOS builds cannot be made on Windows/Linux |

### Step-by-step

1. **Open a terminal in this `pixel-tasker` folder** (the one with `index.html` in it).
   Capacitor treats this whole folder as the "web app" it wraps — since `webDir` in
   `capacitor.config.json` is already set to `.`, there's no separate build step needed.

2. **Install the Capacitor packages:**
   ```bash
   npm install @capacitor/core @capacitor/cli
   ```
   This reuses the `package.json` already in this folder (the one also used for the
   Electron build) — npm will just add Capacitor to its dependencies.

3. **Verify the config** — `npx cap init` normally asks for the app name/ID
   interactively, but since `capacitor.config.json` already exists with:
   ```json
   { "appId": "com.example.pixeltasker", "appName": "Pixel Tasker", "webDir": "." }
   ```
   you can skip straight to adding platforms. (Change `appId` first if you want your own
   reverse-domain identifier, e.g. `com.yourname.pixeltasker` — you can't change it later
   without losing your place on the app stores.)

4. **Add the platform(s) you want:**
   ```bash
   npm install @capacitor/android
   npx cap add android
   ```
   ```bash
   npm install @capacitor/ios      # macOS only
   npx cap add ios
   ```
   This generates full native `android/` and/or `ios/` project folders alongside
   `index.html`.

5. **Sync your web files into the native project** (re-run this any time you edit
   `index.html`):
   ```bash
   npx cap sync
   ```

6. **Open and run it:**
   ```bash
   npx cap open android    # opens Android Studio
   npx cap open ios        # opens Xcode (macOS only)
   ```
   In Android Studio, hit the green ▶ Run button and pick a connected device or a
   virtual one from the Device Manager. In Xcode, pick a simulator or your plugged-in
   iPhone from the device dropdown, then hit ▶.
   You can also skip the IDE and run directly from the terminal with
   `npx cap run android` or `npx cap run ios`, though `open` gives you more control.

### Custom app icon and splash screen

The `icon-512.png` in this folder is a good source image. Generate all the native icon
and splash sizes automatically with:
```bash
npm install -D @capacitor/assets
mkdir assets
cp icon-512.png assets/icon.png
cp icon-512.png assets/splash.png
npx capacitor-assets generate
npx cap sync
```

### Building a signed release (for the Play Store / App Store)

- **Android:** In Android Studio, `Build → Generate Signed Bundle / APK`, create (or
  reuse) a keystore, and build an `.aab` (for Play Store upload) or `.apk` (for direct
  installs). Full walkthrough: [Android app signing docs](https://developer.android.com/studio/publish/app-signing).
- **iOS:** In Xcode, set your Team under `Signing & Capabilities`, then
  `Product → Archive`, and use the Organizer window to upload to App Store Connect /
  TestFlight. You'll need an active Apple Developer Program membership ($99/yr).
- Both stores also require a one-time developer account: Google Play ($25 one-time),
  Apple Developer Program ($99/yr).

### Common gotchas

- **Blank screen on launch:** almost always a `webDir` mismatch — double check
  `capacitor.config.json` still points at `.` (this folder), then re-run `npx cap sync`.
- **Changes not showing up:** you edited `index.html` but forgot `npx cap sync` — the
  native project has its own copy of the web files that only updates when you sync.
- **The service worker (`sw.js`):** it's there for the PWA/browser install path (step 2)
  and is harmless inside Capacitor, but Capacitor apps don't need it — the native shell
  already bundles the files locally, so you can ignore any console messages about it.
- **iOS builds need a Mac:** if you're on Windows/Linux, use a cloud Mac build service
  (e.g. Codemagic, Ionic Appflow) or skip iOS and ship Android + the PWA/desktop options
  instead.

## Which option should I pick?

| Goal | Best option |
|---|---|
| Quickest way to get an "app icon" on my phone or desktop | PWA install (step 2) |
| A real `.exe`/`.dmg` to share with others, no browser | Electron (step 3) |
| Something installable from the Play Store / App Store | Capacitor (step 4) |

## Backing up your data

Use the export/import buttons (⇓ / ⇑) in the top bar to save your tasks to a `.json`
file, or restore from one — handy before switching devices or reinstalling.

## Files in this folder

- `index.html` — the whole app (HTML/CSS/JS, no build step required)
- `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png` — PWA support
- `electron/main.js`, `package.json` — Electron desktop packaging
